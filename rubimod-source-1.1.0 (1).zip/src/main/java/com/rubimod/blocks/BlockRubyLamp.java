package com.rubimod.blocks;

import com.rubimod.RubiMod;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;

/** Lampara de rubi: bloque decorativo con luz maxima. */
public class BlockRubyLamp extends Block {

    public BlockRubyLamp() {
        super(Material.GLASS);
        setRegistryName(RubiMod.MODID, "ruby_lamp");
        setUnlocalizedName(RubiMod.MODID + ".ruby_lamp");
        setCreativeTab(RubiMod.TAB);
        setSoundType(SoundType.GLASS);
        setHardness(0.5F);
        setResistance(3.0F);
        setLightLevel(1.0F);
    }
}
