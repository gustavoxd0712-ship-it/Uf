package com.rubimod.init;

import com.rubimod.blocks.BlockRubyBlock;
import com.rubimod.blocks.BlockRubyLamp;
import com.rubimod.blocks.BlockRubyOre;
import net.minecraft.block.Block;

import java.util.ArrayList;
import java.util.List;

public final class ModBlocks {

    public static final List<Block> BLOCKS = new ArrayList<>();

    public static final Block RUBY_ORE = add(new BlockRubyOre());
    public static final Block RUBY_BLOCK = add(new BlockRubyBlock());
    public static final Block RUBY_LAMP = add(new BlockRubyLamp());

    private static Block add(Block block) {
        BLOCKS.add(block);
        return block;
    }

    private ModBlocks() {
    }
}
