package com.rubimod.init;

import com.rubimod.RubiMod;
import com.rubimod.items.ItemRubyApple;
import com.rubimod.items.ItemRubyArmor;
import com.rubimod.items.ItemRubySword;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSpade;
import net.minecraftforge.common.util.EnumHelper;

import java.util.ArrayList;
import java.util.List;

public final class ModItems {

    public static final List<Item> ITEMS = new ArrayList<>();

    // Materiales: un poco mejores que el diamante
    public static final Item.ToolMaterial RUBY_TOOL =
            EnumHelper.addToolMaterial("RUBY", 3, 1800, 8.5F, 3.5F, 18);

    public static final ItemArmor.ArmorMaterial RUBY_ARMOR =
            EnumHelper.addArmorMaterial("RUBY", RubiMod.MODID + ":ruby", 36,
                    new int[]{3, 6, 8, 3}, 20, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 2.5F);

    // Items basicos
    public static final Item RUBY = reg(new Item(), "ruby");
    public static final Item RUBY_APPLE = reg(new ItemRubyApple(), "ruby_apple");

    // Herramientas
    public static final Item RUBY_SWORD = reg(new ItemRubySword(RUBY_TOOL), "ruby_sword");
    public static final Item RUBY_PICKAXE = reg(new ItemPickaxe(RUBY_TOOL) { }, "ruby_pickaxe");
    public static final Item RUBY_AXE = reg(new ItemAxe(RUBY_TOOL, 5.0F, -3.0F) { }, "ruby_axe");
    public static final Item RUBY_SHOVEL = reg(new ItemSpade(RUBY_TOOL), "ruby_shovel");
    public static final Item RUBY_HOE = reg(new ItemHoe(RUBY_TOOL), "ruby_hoe");

    // Armadura
    public static final Item RUBY_HELMET = reg(new ItemRubyArmor(RUBY_ARMOR, EntityEquipmentSlot.HEAD), "ruby_helmet");
    public static final Item RUBY_CHESTPLATE = reg(new ItemRubyArmor(RUBY_ARMOR, EntityEquipmentSlot.CHEST), "ruby_chestplate");
    public static final Item RUBY_LEGGINGS = reg(new ItemRubyArmor(RUBY_ARMOR, EntityEquipmentSlot.LEGS), "ruby_leggings");
    public static final Item RUBY_BOOTS = reg(new ItemRubyArmor(RUBY_ARMOR, EntityEquipmentSlot.FEET), "ruby_boots");

    private static Item reg(Item item, String name) {
        item.setRegistryName(RubiMod.MODID, name);
        item.setUnlocalizedName(RubiMod.MODID + "." + name);
        item.setCreativeTab(RubiMod.TAB);
        ITEMS.add(item);
        return item;
    }

    private ModItems() {
    }
}
