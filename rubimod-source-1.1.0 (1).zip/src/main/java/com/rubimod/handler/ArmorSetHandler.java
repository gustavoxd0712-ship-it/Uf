package com.rubimod.handler;

import com.rubimod.RubiMod;
import com.rubimod.init.ModItems;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Bonus del set completo de rubi: Resistencia al fuego + Prisa I. */
@Mod.EventBusSubscriber(modid = RubiMod.MODID)
public class ArmorSetHandler {

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        EntityPlayer player = event.player;
        if (player.world.isRemote || player.ticksExisted % 20 != 0) {
            return;
        }
        if (hasFullSet(player)) {
            player.addPotionEffect(new PotionEffect(MobEffects.FIRE_RESISTANCE, 240, 0, true, false));
            player.addPotionEffect(new PotionEffect(MobEffects.HASTE, 240, 0, true, false));
        }
    }

    private static boolean hasFullSet(EntityPlayer player) {
        return player.getItemStackFromSlot(EntityEquipmentSlot.HEAD).getItem() == ModItems.RUBY_HELMET
                && player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() == ModItems.RUBY_CHESTPLATE
                && player.getItemStackFromSlot(EntityEquipmentSlot.LEGS).getItem() == ModItems.RUBY_LEGGINGS
                && player.getItemStackFromSlot(EntityEquipmentSlot.FEET).getItem() == ModItems.RUBY_BOOTS;
    }
}
