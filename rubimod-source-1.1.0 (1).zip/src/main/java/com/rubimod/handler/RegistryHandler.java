package com.rubimod.handler;

import com.rubimod.RubiMod;
import com.rubimod.init.ModBlocks;
import com.rubimod.init.ModItems;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = RubiMod.MODID)
public class RegistryHandler {

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        event.getRegistry().registerAll(ModBlocks.BLOCKS.toArray(new Block[0]));
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        List<Item> all = new ArrayList<>(ModItems.ITEMS);
        for (Block block : ModBlocks.BLOCKS) {
            Item itemBlock = new ItemBlock(block);
            itemBlock.setRegistryName(block.getRegistryName());
            all.add(itemBlock);
        }
        event.getRegistry().registerAll(all.toArray(new Item[0]));
    }
}
