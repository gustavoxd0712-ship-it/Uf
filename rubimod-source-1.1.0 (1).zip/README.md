# Rubi Mod 1.1.0 (Minecraft 1.12.2 · Forge 14.23.5.2860)

## Contenido
- Mena, gema y bloque de rubí (ya existían). La mena también se funde en horno.
- **Herramientas**: espada (prende fuego), pico, hacha, pala y azada de rubí.
- **Armadura** de rubí (casco, peto, pantalones, botas). Set completo = Resistencia al fuego + Prisa I.
- **Manzana de rubí**: Regeneración II + Absorción.
- **Lámpara de rubí**: bloque con luz máxima (receta da 2).
- El rubí repara herramientas y armaduras de rubí en el yunque.

## Recetas
Herramientas y armaduras: igual que las de diamante, cambiando diamantes por rubíes.
Manzana: 4 rubíes en cruz + manzana. Lámpara: 4 rubíes en cruz + bloque de piedra luminosa.

## Compilar con GitHub Actions
1. Crea un repositorio en GitHub y sube TODO el contenido de esta carpeta (con `.github/workflows/build.yml`).
2. Entra en la pestaña **Actions**; se ejecuta solo (o pulsa "Run workflow").
3. Al terminar, abre la ejecución y descarga **rubimod-jar** en la sección *Artifacts*.
4. Dentro del .zip descargado está `rubimod-1.1.0.jar`; cópialo a la carpeta `mods` de Forge 1.12.2.
